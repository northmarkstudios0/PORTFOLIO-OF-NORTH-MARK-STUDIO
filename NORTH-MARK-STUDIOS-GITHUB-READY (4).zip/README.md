# NORTH MARK STUDIOS — GitHub Pages Ready

## Publish this website

1. Extract this ZIP on your computer.
2. Open your GitHub repository.
3. Upload the **contents** of this folder, not the ZIP file itself.
4. Make sure `index.html` is in the repository's top/root level and the `assets` folder is beside it.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/(root)`, then click **Save**.
8. Wait a few minutes and open the URL shown in Settings → Pages.

## Important
- Keep the `assets` folder beside `index.html`; the HTML references these files.
- Do not rename `index.html` or the `assets` folder.
- This package is for a static website. It does not include a server-side backend.
